package dao;

import pojos.Club;

public class DaoClub extends DaoGenericoHibernate<Club, Integer>{

}
