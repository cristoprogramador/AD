package dao;

import pojos.Cancion;

public class DaoCancion extends DaoGenericoHibernate<Cancion, Integer>{

}
