package interfaz;

public class Ejercicio_4 {

	public static void main(String[] args) {

	}

}
