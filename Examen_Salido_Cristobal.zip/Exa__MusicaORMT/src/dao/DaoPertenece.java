package dao;

import pojos.Pertenece;
import pojos.PerteneceId;

public class DaoPertenece extends DaoGenericoHibernate<Pertenece, PerteneceId>{

}
