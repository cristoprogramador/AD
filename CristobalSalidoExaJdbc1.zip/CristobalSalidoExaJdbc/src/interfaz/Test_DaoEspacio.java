package interfaz;

import dao.DaoEspacio;

public class Test_DaoEspacio {
	public static void main(String[] args) {
		DaoEspacio de = new DaoEspacio();
		
	}
}
